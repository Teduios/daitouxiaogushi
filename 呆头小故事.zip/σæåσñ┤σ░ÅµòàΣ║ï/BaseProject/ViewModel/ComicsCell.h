//
//  ComicsCell.h
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComicsCell : UITableViewCell

@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UIImageView *coverImageView;
@property (nonatomic,strong)UILabel *likesCountLb;
@property (nonatomic,strong)UIImageView *likeImage;
@property (nonatomic,strong)UILabel *wan;
@end
