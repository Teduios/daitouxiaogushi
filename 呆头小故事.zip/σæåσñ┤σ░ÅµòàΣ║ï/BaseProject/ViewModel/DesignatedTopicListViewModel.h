//
//  DesignatedTopicListViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import <MJExtension.h>
@interface DesignatedTopicListViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
-(NSURL *)coverImageURLForRow:(NSUInteger)row;
-(NSString *)titleForRow:(NSUInteger)row;
-(NSUInteger)likesCountForRow:(NSUInteger)row;
-(NSUInteger)IDForRow:(NSUInteger)row;

@property (nonatomic)NSInteger ID;
@end
