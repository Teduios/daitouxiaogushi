//
//  VideoViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewModel.h"
#import "VideoModel.h"
#import "VideoNetManager.h"
@implementation VideoViewModel
-(NSInteger)rowNumber{
  return self.dataArr.count;
}
-(VideoItemsModel *)VideoInfoForRow:(NSUInteger)row{
    return self.dataArr[row];
}

//标题
-(NSString *)contentForRow:(NSUInteger)row{
    return [self VideoInfoForRow:row].content;
}
//作者名
-(NSString *)logLinForRow:(NSUInteger)row{
    return [self VideoInfoForRow:row].user.login;
}
//作者头像
-(NSURL *)picURLForRow:(NSUInteger)row{
    return [NSURL URLWithString:[self VideoInfoForRow:row].pic_url];
}
//评论数量
-(NSUInteger)commentsCountForRow:(NSUInteger)row{
    NSString *likeCount = [NSString stringWithFormat:@"%ld",(long)[self VideoInfoForRow:row].comments_count];
    if (likeCount.length >=3) {
        likeCount = [likeCount substringToIndex:3];
    }else if (likeCount.length == 2){
        likeCount = [likeCount substringToIndex:2];
    }else{
        likeCount = [likeCount substringToIndex:1];
    }
    
    return likeCount.integerValue;
}
//分享次数
-(NSUInteger)shareCountForRow:(NSUInteger)row{
    NSString *sharCount = [NSString stringWithFormat:@"%ld",(long)[self VideoInfoForRow:row].share_count];
    if (sharCount.length >= 3) {
        sharCount = [sharCount substringToIndex:3];
    }else if (sharCount.length == 2){
        sharCount = [sharCount substringToIndex:2];
    }else{
        sharCount = [sharCount substringToIndex:1];
    }
    
    return sharCount.integerValue;
}
//视频
-(NSURL *)highURLForRow:(NSUInteger)row{
    return [NSURL URLWithString:[self VideoInfoForRow:row].high_url];
}


-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page = 0;
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}


-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page += 1;
    
    [self getDataFromNetCompleteHandle:completionHandle];
}


-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [VideoNetManager getVideoInfoFromPage:self.page completionHandle:^(VideoModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.items];
        completionHandle(error);
    }];
}



@end
