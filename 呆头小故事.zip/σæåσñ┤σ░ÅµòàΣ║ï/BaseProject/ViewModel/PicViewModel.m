//
//  PicViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewModel.h"
#import "PicModel.h"
#import "PicNetManager.h"

@implementation PicViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(PicItemsModel *)PicInfoForRow:(NSUInteger)row{
    return self.dataArr[row];
}




-(NSURL *)iconForRow:(NSUInteger)row{
    NSString *userID = [NSString stringWithFormat:@"%ld",(unsigned long)[self userIDForRow:row]];
    NSString *userIDList;
    if (userID.length >= 4) {
        userIDList = [userID substringToIndex:4];
    }
    NSString *iconIDSuffix = [self iconSuffixForRow:row];
    NSString *path = [NSString stringWithFormat:@"http://pic.qiushibaike.com/system/avtnew/%ld/%ld/medium/%@",(long)userIDList.integerValue,(long)userID.integerValue,iconIDSuffix];
    
    return [NSURL URLWithString:path];
}
-(NSURL *)imageForRow:(NSUInteger)row{
    NSString *imageID = [NSString stringWithFormat:@"%ld",(unsigned long)[self imageIDForRow:row]];
    NSString *imageIDList = [imageID substringToIndex:5];
    NSString *imageSuffix = [self imageSuffixForRow:row];
    NSString *path = [NSString stringWithFormat:@"http://pic.qiushibaike.com/system/pictures/%ld/%ld/medium/%@",(long)imageIDList.integerValue,(long)imageID.integerValue,imageSuffix];
    return [NSURL URLWithString:path];
}
-(NSString *)contentForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].content;
}
-(NSString *)loginForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].user.login;
}



-(NSUInteger)userIDForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].user.ID;
}
-(NSUInteger)imageIDForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].ID;
}

-(NSString *)iconSuffixForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].user.icon;
}
-(NSString *)imageSuffixForRow:(NSUInteger)row{
    return [self PicInfoForRow:row].image;
  
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page = 0;
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [PicNetManager getPicInfoFromPage:self.page completionHandle:^(PicModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObjectsFromArray:model.items];
        }
        completionHandle(error);
    }];
}







@end
