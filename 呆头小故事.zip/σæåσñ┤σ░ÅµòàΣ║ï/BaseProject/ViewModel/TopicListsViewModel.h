//
//  TopicListsViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "TopicListsNetManager.h"
@interface TopicListsViewModel : BaseViewModel

@property (nonatomic)NSInteger rowNumber;

-(NSURL *)coverImageForRow:(NSUInteger)row;
-(NSString *)titleForRow:(NSUInteger)row;
-(NSString *)nickNameForRow:(NSUInteger)row;
-(NSUInteger)likesCountForRow:(NSUInteger)row;
-(NSUInteger)commentsCountForRow:(NSUInteger)row;
-(NSString *)descForRow:(NSUInteger)row;
-(NSUInteger)IDForRow:(NSUInteger)row;
@property (nonatomic)NSInteger offset;

-(id)initWithNewsListType:(CartoonListType)type;
@property (nonatomic)CartoonListType type;



@end
