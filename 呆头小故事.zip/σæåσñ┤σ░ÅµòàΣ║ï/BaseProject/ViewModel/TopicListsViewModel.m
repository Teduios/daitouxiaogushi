//
//  TopicListsViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicListsViewModel.h"
#import "TopicListsModel.h"
#import "TopicListsNetManager.h"

@interface TopicListsViewModel()


@end



@implementation TopicListsViewModel


-(id)initWithNewsListType:(CartoonListType)type{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}



-(NSInteger)rowNumber{
    return self.dataArr.count;
}

//-(TopicListsDataModel *)TopListsForRow:(NSUInteger)row{
//    return self.dataArr[row];
//}

-(TopicListsDataTopicsModel *)TopListForRow:(NSUInteger)row{
    return self.dataArr[row];
}
//-(NSURL *)coverImageForRow:(NSUInteger)row{

//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
    
//    NSString *str = [dic objectForKey:@"cover_image_url"];
//    NSURL *url = [NSURL URLWithString:str];
//    return [NSURL URLWithString:dic.cover_image_url];
//}
//-(NSString *)titleForRow:(NSUInteger)row{
//    
//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString *title = [dic objectForKey:@"title"];
//    return dic.title;
//}
//-(NSString *)nickNameForRow:(NSUInteger)row{
//    
//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString *nickname = [dic objectForKey:@"nickname"];
//    return dic.user.nickname;
//}
//-(NSUInteger)IDForRow:(NSUInteger)row{
//    
//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString  *ID = [dic objectForKey:@"ID"];
//    
//    return dic.ID;
//}
//-(NSUInteger)likesCountForRow:(NSUInteger)row{
//     TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString *str = [dic objectForKey:@"likes_count"];
//    NSString *likeCount = [NSString stringWithFormat:@"%ld",dic.likes_count];
//    likeCount = [likeCount substringToIndex:3];
//    NSLog(@"%@",likeCount);
//    return  likeCount.integerValue;
//}
//-(NSUInteger)commentsCountForRow:(NSUInteger)row{
//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString *str = [dic objectForKey:@"comments_count"];
//    NSString *commentCount = [NSString stringWithFormat:@"%ld",dic.comments_count];
//    commentCount = [commentCount substringToIndex:3];
//    return commentCount.integerValue;
//}
////-(NSString*)UTF8_To_GB2312:(NSString*)utf8string
////{
////    NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingUTF8);
////    NSData* gb2312data = [utf8string dataUsingEncoding:encoding];
////    return [[NSString alloc] initWithData:gb2312data encoding:encoding];
////}
//
//-(NSString *)descForRow:(NSUInteger)row{
//    TopicListsDataTopicsModel *dic = [[self TopListsForRow:row].topics objectAtIndex:row];
////    NSString *str = [dic objectForKey:@"desc"];
//    return dic.desc;
//}

-(NSURL *)coverImageForRow:(NSUInteger)row{
    return [NSURL URLWithString:[self TopListForRow:row].cover_image_url];
}
-(NSString *)titleForRow:(NSUInteger)row{
    return [self TopListForRow:row].title;
}
-(NSString *)nickNameForRow:(NSUInteger)row{
    return [self TopListForRow:row].user.nickname;
}
-(NSUInteger)likesCountForRow:(NSUInteger)row{
    NSString *likeCount = [NSString stringWithFormat:@"%ld",(long)[self TopListForRow:row].likes_count];
        likeCount = [likeCount substringToIndex:3];
    NSLog(@"%@",likeCount);

    return likeCount.integerValue;
}
-(NSUInteger)commentsCountForRow:(NSUInteger)row{
    NSString *commentCount = [NSString stringWithFormat:@"%ld",(long)[self TopListForRow:row].comments_count];
    if (commentCount.length == 3) {
        commentCount = [commentCount substringToIndex:3];
    }else if (commentCount.length == 2){
        commentCount = [commentCount substringToIndex:2];
    }else if (commentCount.length == 1){
        commentCount = [commentCount substringToIndex:1];
    }else{
        commentCount = [commentCount substringToIndex:3];
    }
    
    return commentCount.integerValue;
}
-(NSString *)descForRow:(NSUInteger)row{
    return [self TopListForRow:row].desc;
}
-(NSUInteger)IDForRow:(NSUInteger)row{
    return [self TopListForRow:row].ID;
}








-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.offset = 0;
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.offset += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
//    self.dataTask = [TopicListsNetManager getTopListsFromoffset:self.offset completionHandle:^(TopicListsModel *model, NSError *error) {   
//        if (!error) {
//            [self.dataArr addObjectsFromArray:model.data.topics];
//            completionHandle(error);
//        }
//    }];
//}


-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [TopicListsNetManager getCartoonList:self.type page:self.offset completionHandle:^(TopicListsModel *model, NSError *error) {
        if (self.offset == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data.topics];
        completionHandle(error);
        
    }];
}


@end
