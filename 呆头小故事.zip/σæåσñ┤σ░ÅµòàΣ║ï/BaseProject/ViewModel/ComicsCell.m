//
//  ComicsCell.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComicsCell.h"

@implementation ComicsCell
//图片
-(UIImageView *)coverImageView{
    if (!_coverImageView) {
        _coverImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_coverImageView];
        _coverImageView.contentMode = UIViewContentModeScaleAspectFit;
        [_coverImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.width.mas_equalTo(90/(640/348));
            
        }];
    }
    return _coverImageView;
}
//题目
-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        [self.contentView addSubview:_titleLb];
        self.titleLb.font = [UIFont systemFontOfSize:16];
        _titleLb.numberOfLines = 0;
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(_coverImageView.mas_right).mas_equalTo(20);
            make.width.mas_lessThanOrEqualTo(200);
            
        }];
    }
    return _titleLb;
}
//喜欢图标
-(UIImageView *)likeImage{
    if (!_likeImage) {
        _likeImage = [[UIImageView alloc]init];
        [self.contentView addSubview:_likeImage];
        _likeImage.contentMode = UIViewContentModeScaleAspectFit;
        [_likeImage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(40);
            make.right.mas_equalTo(-80);
            make.width.height.mas_equalTo(21);
        }];
    }
    return _likeImage;
}

//喜欢数量
-(UILabel *)likesCountLb{
    if (!_likesCountLb) {
        _likesCountLb = [[UILabel alloc]init];
        [self.contentView addSubview:_likesCountLb];
        self.likesCountLb.font = [UIFont systemFontOfSize:14];
        self.likesCountLb.textColor = [UIColor grayColor];
        [_likesCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(45);
            make.height.mas_equalTo(17);
            make.width.mas_lessThanOrEqualTo(35);
            make.right.mas_equalTo(-48);
        }];
    }
    return _likesCountLb;
}
//万
-(UILabel *)wan{
    if (!_wan) {
        _wan = [[UILabel alloc]init];
        [self.contentView addSubview:_wan];
        _wan.textColor = [UIColor grayColor];
        _wan.font = [UIFont systemFontOfSize:14];
        
        [_wan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.height.mas_equalTo(16);
            make.top.mas_equalTo(45);
            make.right.mas_equalTo(-30);
        }];
    }
    return _wan;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
