//
//  DesignatedTopicListViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DesignatedTopicListViewModel.h"
#import "DesignatedTopicListModel.h"
#import "DesignatedTopicListNetManager.h"
@implementation DesignatedTopicListViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(DesignatedTopicListDataComicsModel *)getDesignatedTopicListDataForRow:(NSUInteger)row{
    return self.dataArr[row];
}

-(NSURL *)coverImageURLForRow:(NSUInteger)row{
    //取数组中的元素
    return [NSURL URLWithString:[self getDesignatedTopicListDataForRow:row].cover_image_url];
   
}
-(NSString *)titleForRow:(NSUInteger)row{

    return [self getDesignatedTopicListDataForRow:row].title;
}
-(NSUInteger)likesCountForRow:(NSUInteger)row{
    NSString *count = [NSString stringWithFormat:@"%ld",(long)[self getDesignatedTopicListDataForRow:row].likes_count];
    if (count.length >= 3) {
        count = [count substringToIndex:3];
    }
    return count.integerValue;
}

-(NSUInteger)IDForRow:(NSUInteger)row{
    return [self getDesignatedTopicListDataForRow:row].ID;
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    [self getDataFromNetCompleteHandle:completionHandle];
    
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [DesignatedTopicListNetManager getTopListsFromID:self.ID completionHandle:^(DesignatedTopicListModel *model, NSError *error) {
        if (!error) {
            if (self.ID != 0) {
                [self.dataArr addObjectsFromArray:model.data.comics];
                completionHandle(error);
            }
        }
    }];
}
@end
