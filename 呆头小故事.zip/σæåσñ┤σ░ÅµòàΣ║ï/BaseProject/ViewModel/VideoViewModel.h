//
//  VideoViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface VideoViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;

-(NSString *)contentForRow:(NSUInteger)row;//标题
-(NSString *)logLinForRow:(NSUInteger)row;//作者名
-(NSURL *)picURLForRow:(NSUInteger)row;//作者头像
-(NSUInteger)commentsCountForRow:(NSUInteger)row;//评论数量
-(NSUInteger)shareCountForRow:(NSUInteger)row;//分享次数
-(NSURL *)highURLForRow:(NSUInteger)row;//视频

@property (nonatomic)NSInteger page;//页数
@end
