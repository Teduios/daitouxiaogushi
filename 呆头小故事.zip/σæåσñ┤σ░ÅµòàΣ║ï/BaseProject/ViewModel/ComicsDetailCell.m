//
//  ComicsDetailCell.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComicsDetailCell.h"

@implementation ComicsDetailCell
-(UIImageView *)image{
    if (!_image) {
        _image = [[UIImageView alloc]init];
        [self.contentView addSubview:self.image];
        _image.contentMode = UIViewContentModeScaleToFill;
        [_image mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(1);
            
        }];
    }
    return _image;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
