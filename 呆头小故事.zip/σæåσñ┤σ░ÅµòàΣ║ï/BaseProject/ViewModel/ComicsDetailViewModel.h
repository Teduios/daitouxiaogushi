//
//  ComicsDetailViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ComicsDetailModel.h"
@interface ComicsDetailViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
@property (nonatomic)NSInteger ID;
-(NSArray *)imagesForRow:(NSUInteger)row;
-(ComicsDetailDataModel *)ComicsDetailForRow:(NSUInteger)row;
@end
