//
//  TopicListsCell.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicListsCell.h"






@implementation TopicListsCell
//图片
-(UIImageView *)coverImageView{
    if (!_coverImageView) {
        _coverImageView = [[UIImageView alloc]init];
        
        [self.contentView addSubview:_coverImageView];
        _coverImageView.contentMode = UIViewContentModeScaleAspectFill;
        [_coverImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.left.mas_equalTo(70);
            make.height.mas_equalTo(70);
            make.width.mas_equalTo(70*(360/640));
        }];
    }
    return _coverImageView;
}
//题目
-(UILabel *)titleLb{
    if (!_titleLb) {
        _titleLb = [[UILabel alloc]init];
        [self.contentView addSubview:_titleLb];
        _titleLb.numberOfLines = 0;
//        _titleLb.textAlignment = NSTextAlignmentRight;
        self.titleLb.font = [UIFont systemFontOfSize:17];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(_coverImageView.mas_right).mas_equalTo(90);
            make.width.mas_lessThanOrEqualTo(100);
            
        }];
    }
    return _titleLb;
}


//作者
-(UILabel *)nickNameLb{
    if (!_nickNameLb) {
        _nickNameLb = [[UILabel alloc]init];
        [self.contentView addSubview: _nickNameLb];
        _nickNameLb.numberOfLines = 0;
//        _nickNameLb.textAlignment = NSTextAlignmentLeft;
        _nickNameLb.font = [UIFont systemFontOfSize:15];
        [_nickNameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(_titleLb.mas_right).mas_equalTo(20);
            make.width.mas_lessThanOrEqualTo(100);
            
        }];
    }
    return _nickNameLb;
}
//赞图标
-(UIImageView *)zan{
    if (!_zan) {
        _zan = [[UIImageView alloc]init];
        [self.contentView addSubview:_zan];
        [_zan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-168);
            make.width.height.mas_equalTo(20);
            
        }];
    }
    return _zan;
}
//喜欢数
-(UILabel *)likesCountLb{
    if (!_likesCountLb) {
        _likesCountLb = [[UILabel alloc]init];
        [self.contentView addSubview:_likesCountLb];
        _likesCountLb.font = [UIFont systemFontOfSize:16];
        _likesCountLb.textColor = [UIColor grayColor];
        [_likesCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-136);
            make.width.mas_lessThanOrEqualTo(200);
        }];
        
    }
    return _likesCountLb;
}

//喜欢万
-(UILabel *)likeWan{
    if (!_likeWan) {
        _likeWan = [[UILabel alloc]init];
        [self.contentView addSubview:_likeWan];
        _likeWan.textColor = [UIColor grayColor];
        _likeWan.font = [UIFont systemFontOfSize:16];
        [_likeWan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-117);
        }];
    }
    return _likeWan;
}

//评论图标
-(UIImageView *)commentIcon{
    if (!_commentIcon) {
        _commentIcon = [[UIImageView alloc]init];
        [self.contentView addSubview:_commentIcon];
        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-78);
            make.width.height.mas_equalTo(20);
        }];
    }
    return _commentIcon;
}


//评论数
-(UILabel *)commentsCountLb{
    if (!_commentsCountLb) {
        _commentsCountLb = [[UILabel alloc]init];
        [self.contentView addSubview:_commentsCountLb];
        _commentsCountLb.textColor = [UIColor grayColor];
        _commentsCountLb.font = [UIFont systemFontOfSize:16];
        [_commentsCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-48);
            make.width.mas_lessThanOrEqualTo(40);
            
        }];
    }
    return _commentsCountLb;
}
//评论万
-(UILabel *)commentWan{
    if (!_commentWan) {
        _commentWan = [[UILabel alloc]init];
        [self.contentView addSubview:_commentWan];
        _commentWan.textColor = [UIColor grayColor];
        _commentWan.font = [UIFont systemFontOfSize:16];
        [_commentWan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(50);
            make.right.mas_equalTo(-30);
        }];
    }
    return _commentWan;
}

//描述
-(TTTAttributedLabel *)descLb{
    if (!_descLb) {
        _descLb = [[TTTAttributedLabel alloc]initWithFrame:CGRectZero];
        [self.contentView addSubview:_descLb];
        _descLb.font = [UIFont systemFontOfSize:15];
        _descLb.textColor = kRGBColor(106, 64, 36);
        _descLb.lineSpacing = 2;
        _descLb.numberOfLines = 0;
        [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_coverImageView.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.right.mas_equalTo(-10);
        }];
    }
    return _descLb;
}






- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
