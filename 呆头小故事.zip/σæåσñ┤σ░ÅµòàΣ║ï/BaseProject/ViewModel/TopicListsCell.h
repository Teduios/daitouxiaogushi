//
//  TopicListsCell.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"
@interface TopicListsCell : UITableViewCell

@property (nonatomic,strong)UIImageView *coverImageView;
@property (nonatomic,strong)UILabel *titleLb;//题目
@property (nonatomic,strong)UILabel *nickNameLb;//作者
@property (nonatomic,strong)UILabel *likesCountLb;//喜欢数量
@property (nonatomic,strong)UILabel *commentsCountLb;//评论数量
@property (nonatomic,strong)TTTAttributedLabel *descLb;//描述
@property (nonatomic,strong)UIImageView *zan;//赞图标
@property (nonatomic,strong)UIImageView *commentIcon;//评论图标
@property (nonatomic,strong)UILabel *likeWan;
@property (nonatomic,strong)UILabel *commentWan;
@end
