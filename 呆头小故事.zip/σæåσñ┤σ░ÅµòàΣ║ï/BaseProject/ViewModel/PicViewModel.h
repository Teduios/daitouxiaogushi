//
//  PicViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface PicViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
-(NSURL *)iconForRow:(NSUInteger)row;
-(NSString *)contentForRow:(NSUInteger)row;
-(NSString *)loginForRow:(NSUInteger)row;
-(NSURL *)imageForRow:(NSUInteger)row;

-(NSUInteger)userIDForRow:(NSUInteger)row;
-(NSUInteger)imageIDForRow:(NSUInteger)row;
-(NSString *)iconSuffixForRow:(NSUInteger)row;
-(NSString *)imageSuffixForRow:(NSUInteger)row;

@property (nonatomic)NSUInteger page;
@end
