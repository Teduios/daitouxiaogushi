//
//  ComicsDetailViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComicsDetailViewModel.h"
#import "ComicsDetailModel.h"
#import "ComicsDetailNetManager.h"
@implementation ComicsDetailViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}
-(ComicsDetailDataModel *)ComicsDetailForRow:(NSUInteger)row{
    return self.dataArr[row];
}


-(NSArray *)imagesForRow:(NSUInteger)row{
    return self.dataArr;
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    [self.dataArr removeAllObjects];
    
    
    
    
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [ComicsDetailNetManager getComicsDetailFromID:self.ID completionHandle:^(ComicsDetailModel *model, NSError *error) {
        if (!error) {
            self.dataArr = model.data.images.mutableCopy;
            completionHandle(error);
        }

        
    }];
                     
}

@end
