//
//  picAndTextViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "picAndTextViewModel.h"
#import "picAndTextModel.h"
#import "picAndTextNetManager.h"
@implementation picAndTextViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}
-(picAndTextItemsModel *)getPicAndTextForRow:(NSUInteger)row{
    return self.dataArr[row];
}


-(NSString *)loginForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].user.login;
}
//头像图片
-(NSURL *)headIconForRow:(NSUInteger)row{
    NSString *userID = [NSString stringWithFormat:@"%ld",(unsigned long)[self userIDForRow:row]];
    NSString *userIDList;
    if (userID.length >= 4) {
        userIDList = [userID substringToIndex:4];
    }
    NSString *iconID = [self iconForRow:row];
    NSString *path = [NSString stringWithFormat:@"http://pic.qiushibaike.com/system/avtnew/%ld/%ld/medium/%@",(long)userIDList.integerValue,(long)userID.integerValue,iconID];
    NSLog(@"userIDList:%ld",(long)userIDList.integerValue);
    NSLog(@"头像图片：%@",path);
    
    return [NSURL URLWithString:path];
   
}
-(NSString *)contentForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].content;
}

//内容图片
-(NSURL *)imageForRow:(NSUInteger)row{
    NSString *imageID = [NSString stringWithFormat:@"%ld",(unsigned long)[self imageIDForRow:row]];
    NSString *imageIDList = [imageID substringToIndex:5];
    NSString *imageSuffix = [self imageSuffixForRow:row];

    NSString *path = [NSString stringWithFormat:@"http://pic.qiushibaike.com/system/pictures/%ld/%ld/medium/%@",(long)imageIDList.integerValue,(long)imageID.integerValue,imageSuffix];
    NSLog(@"内容图片：%@",path);
    return [NSURL URLWithString:path];
}

//如果想获取图片和头像图片需要获取两个ID
-(NSUInteger)userIDForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].user.ID;
}
-(NSUInteger)imageIDForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].ID;
}

-(NSString *)iconForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].user.icon;
}

-(NSString *)imageSuffixForRow:(NSUInteger)row{
    return [self getPicAndTextForRow:row].image;
}

-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page = 0;
    [self.dataArr removeAllObjects];
    [self getDataFromNetCompleteHandle:completionHandle];
}

-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    self.page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
    
}


-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask = [picAndTextNetManager getPicAndTextInfoFromPage:self.page completionHandle:^(picAndTextModel *model, NSError *error) {
        if (!error) {
            [self.dataArr addObjectsFromArray:model.items];
            completionHandle(error);
        }
    }];
}





@end
