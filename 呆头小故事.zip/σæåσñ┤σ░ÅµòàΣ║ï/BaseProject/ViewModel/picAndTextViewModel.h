//
//  picAndTextViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"

@interface picAndTextViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;

-(NSString *)loginForRow:(NSUInteger)row;
-(NSURL *)headIconForRow:(NSUInteger)row;
-(NSString *)contentForRow:(NSUInteger)row;
-(NSURL *)imageForRow:(NSUInteger)row;

//如果想获取图片和头像图片需要获取两个ID
-(NSUInteger)userIDForRow:(NSUInteger)row;
-(NSUInteger)imageIDForRow:(NSUInteger)row;
-(NSString *)iconForRow:(NSUInteger)row;
-(NSString *)imageSuffixForRow:(NSUInteger)row;


@property (nonatomic)NSInteger page;
@end
