//
//  PictureViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PictureViewController.h"
@interface PictureViewController ()
@end

@implementation PictureViewController
- (UIImageView *)image {
    if(_image == nil) {
        _image = [[UIImageView alloc] init];
    }
    return _image;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
//    MWPhotoBrowser *photoB = [[MWPhotoBrowser alloc]initWithDelegate:self];
//    NSMutableArray *naviVCs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
//    [naviVCs removeLastObject];
//    [naviVCs addObject:photoB];
//    self.navigationController.viewControllers = naviVCs;

    
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.image.contentMode = UIViewContentModeScaleAspectFit;
    [self.view addSubview:self.image];
    NSLog(@"%@",self.image.image);
    [self.image mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];

    UILongPressGestureRecognizer *Gesture = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(Quit)];
    Gesture.minimumPressDuration = 0.05;
    [self.view addGestureRecognizer:Gesture];
    
}

-(void)Quit{
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

//#pragma mark - MWPhotoBrowserDelegate
//-(NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser{
//    return self.picVM.rowNumber;
//}
//-(id<MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index{
//    MWPhoto *photo = [MWPhoto photoWithURL:[self.picVM imageForRow:index]];
//    return photo;
//}


@end
