//
//  PicCell.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicCell.h"

@implementation PicCell
//头像
-(UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_iconImageView];
        [_iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(5);
            make.width.height.mas_equalTo(28);
            
        }];
    }
    return _iconImageView;
}
//名字
-(TTTAttributedLabel *)loginLb{
    if (!_loginLb) {
        _loginLb = [[TTTAttributedLabel alloc]initWithFrame:CGRectZero];
        [self.contentView addSubview:_loginLb];
        _loginLb.textColor = kRGBColor(0, 128, 255);
        _loginLb.font = [UIFont systemFontOfSize:19];
//        _loginLb.highlightedTextColor = [UIColor redColor];
        [_loginLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(11);
            make.left.mas_equalTo(_iconImageView.mas_right).mas_equalTo(5);
            
            make.right.mas_equalTo(-10);
        }];
    }
    return _loginLb;
}
//内容
-(TTTAttributedLabel *)contentLb{
    if (!_contentLb) {
        _contentLb = [[TTTAttributedLabel alloc]initWithFrame:CGRectZero];
        [self.contentView addSubview:_contentLb];
        _contentLb.font = [UIFont systemFontOfSize:18];
        _contentLb.lineSpacing = 2;
        _contentLb.textColor = kRGBColor(90, 90, 140);
        _contentLb.numberOfLines = 0;
        [_contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_iconImageView.mas_bottom).mas_equalTo(15);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
        }];
        
        
    }
    return _contentLb;
}
//图片
-(UIButton *)imageImageView{
    if (!_imageImageView) {
        _imageImageView = [[UIButton alloc]init];
        [self.contentView addSubview:_imageImageView];
        _imageImageView.contentMode = UIViewContentModeScaleAspectFit;
        [_imageImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_contentLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-5);
            make.width.mas_lessThanOrEqualTo(220);
            make.height.mas_lessThanOrEqualTo(200);
            
        }];
    }
    return _imageImageView;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
