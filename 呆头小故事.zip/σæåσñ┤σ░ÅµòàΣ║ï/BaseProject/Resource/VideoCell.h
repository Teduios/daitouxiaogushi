//
//  VideoCell.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
@interface VideoCell : UITableViewCell

@property (nonatomic,strong)UILabel *commentWan;
@property (nonatomic,strong)UILabel *likeWan;
@property (nonatomic,strong)UIImageView *commentIcon;
@property (nonatomic,strong)UIImageView *likeIcon;
@property (nonatomic,strong)UILabel *contentLb;
@property (nonatomic,strong)UILabel *loginLb;
@property (nonatomic,strong)UIImageView *picURLImageView;
@property (nonatomic,strong)UILabel *commentsCountLb;
@property (nonatomic,strong)UILabel *shareCountLb;
@property (nonatomic,strong)UIButton *HighURLBtn;
@property (nonatomic,strong)NSURL *videoURL;//接收传参的URL

+(AVPlayerViewController *)sharedInstance;

@end
