//
//  picAndTextCell.m
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "picAndTextCell.h"
#import "picAndTextViewModel.h"
@implementation picAndTextCell
//头像
-(UIImageView *)iconImageView{
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_iconImageView];
        [_iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(5);
            make.width.height.mas_equalTo(28);
        }];
    }
    return _iconImageView;
}
//名字
-(UILabel *)loginLb{
    if (!_loginLb) {
        _loginLb = [[UILabel alloc]init];
        _loginLb.textColor = kRGBColor(0, 122, 255);
        _loginLb.font = [UIFont systemFontOfSize:18];
        [self.contentView addSubview:_loginLb];
        [_loginLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.left.mas_equalTo(36);
            make.width.mas_lessThanOrEqualTo(300);
        }];
        
    }
    return _loginLb;
}
//内容
-(TTTAttributedLabel *)contentLb{
    if (!_contentLb) {
        _contentLb = [[TTTAttributedLabel alloc]initWithFrame:CGRectZero];
        _contentLb.font = [UIFont systemFontOfSize:14];
        _contentLb.numberOfLines = 0;
        
        _contentLb.delegate = self;//设置代理
        _contentLb.lineSpacing = 2;//行间距
        [self.contentView addSubview:_contentLb];
        [_contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.iconImageView.mas_bottom).mas_equalTo(10);
            make.left.mas_equalTo(10);
            make.right.mas_equalTo(-10);
            
   
        }];
    }
    return _contentLb;
}
//图片
-(UIButton *)imageImageView{
    if (!_imageImageView) {
        _imageImageView = [[UIButton alloc]init];
        _imageImageView.contentMode = UIViewContentModeScaleAspectFit;
        [self.contentView addSubview:_imageImageView];
        [_imageImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.contentLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
           
            make.width.mas_lessThanOrEqualTo(250);
            make.height.mas_lessThanOrEqualTo(200);
            
        }];
    }
    return _imageImageView;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
