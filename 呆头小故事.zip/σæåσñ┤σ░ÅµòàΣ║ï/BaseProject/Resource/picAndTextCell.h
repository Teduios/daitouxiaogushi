//
//  picAndTextCell.h
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"
@interface picAndTextCell : UITableViewCell<TTTAttributedLabelDelegate>
@property (nonatomic,strong)UILabel *loginLb;
@property (nonatomic,strong)UIImageView *iconImageView;
@property (nonatomic,strong)UIButton *imageImageView;
@property (nonatomic,strong)TTTAttributedLabel *contentLb;
@end
