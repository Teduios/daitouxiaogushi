//
//  PicCell.h
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"
@interface PicCell : UITableViewCell
@property (nonatomic,strong)UIImageView *iconImageView;
@property (nonatomic,strong)TTTAttributedLabel *loginLb;
@property (nonatomic,strong)TTTAttributedLabel *contentLb;
@property (nonatomic,strong)UIButton *imageImageView;



@end
