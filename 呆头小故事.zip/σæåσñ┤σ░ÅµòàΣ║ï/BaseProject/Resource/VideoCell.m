
//  VideoCell.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCell.h"
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>

/**
 *  导入第三方库，引入头文件
 */
@implementation VideoCell
//标题
-(UILabel *)contentLb{
    if (!_contentLb) {
        _contentLb = [[UILabel alloc]init];
        [self.contentView addSubview:_contentLb];
        _contentLb.font = [UIFont systemFontOfSize:19];
        _contentLb.numberOfLines = 0;
        [_contentLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.centerX.mas_equalTo(0);
            make.height.mas_lessThanOrEqualTo(200);
        }];
    }
    return _contentLb;
}
//头像
-(UIImageView *)picURLImageView{
    if (!_picURLImageView) {
        _picURLImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_picURLImageView];
        [_picURLImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_contentLb.mas_bottom).mas_equalTo(5);
            make.left.mas_equalTo(10);
            make.width.height.mas_equalTo(28);
            
        }];
    }
    return _picURLImageView;
}
//名字
-(UILabel *)loginLb{
    if (!_loginLb) {
        _loginLb = [[UILabel alloc]init];
        [self.contentView addSubview:_loginLb];
        _loginLb.textColor = kRGBColor(0, 122,255);
        _loginLb.font = [UIFont systemFontOfSize:18];
        [_loginLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(35);
            make.left.mas_equalTo(45);
            make.width.mas_lessThanOrEqualTo(110);
        }];
    }
    return _loginLb;
}
//喜欢图标
- (UIImageView *)likeIcon {
    if(_likeIcon == nil) {
        _likeIcon = [[UIImageView alloc] init];
        [self.contentView addSubview:_likeIcon];
        [_likeIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(61);
            make.width.height.mas_equalTo(22);
            make.right.mas_equalTo(-168);
            
        }];
        
    }
    return _likeIcon;
}
//喜欢数量
-(UILabel *)shareCountLb{
    if (!_shareCountLb) {
        _shareCountLb = [[UILabel alloc]init];
        _shareCountLb.textColor = [UIColor grayColor];
        _shareCountLb.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:_shareCountLb];
        [_shareCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
          make.top.mas_equalTo(63);
            make.width.mas_lessThanOrEqualTo(50);
            make.right.mas_equalTo(-138);
        }];
        
        
    }
    return _shareCountLb;
}
//喜欢万
- (UILabel *)likeWan {
    if(_likeWan == nil) {
        _likeWan = [[UILabel alloc] init];
        [self.contentView addSubview:_likeWan];
        _likeWan.textColor = [UIColor grayColor];
        _likeWan.font = [UIFont systemFontOfSize:16];
        [_likeWan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(63);
            make.right.mas_equalTo(-117);
        }];
    }
    return _likeWan;
}
//评论图标
- (UIImageView *)commentIcon {
    if(_commentIcon == nil) {
        _commentIcon = [[UIImageView alloc] init];
        [self.contentView addSubview:_commentIcon];
        [_commentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(63);
            make.right.mas_equalTo(-80);
            make.width.height.mas_equalTo(22);
        }];
    }
    return _commentIcon;
}
//评论数
-(UILabel *)commentsCountLb{
    if (!_commentsCountLb) {
        _commentsCountLb = [[UILabel alloc]init];
        _commentsCountLb.textColor = [UIColor grayColor];
        _commentsCountLb.font = [UIFont systemFontOfSize:16];
        [self.contentView addSubview:_commentsCountLb];
        [_commentsCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(63);
            make.right.mas_equalTo(-48);
            
        }];
    }
    return _commentsCountLb;
}

//评论：万
- (UILabel *)commentWan {
    if(_commentWan == nil) {
        _commentWan = [[UILabel alloc] init];
        [self.contentView addSubview:_commentWan];
        _commentWan.textColor = [UIColor grayColor];
        _commentWan.font = [UIFont systemFontOfSize:16];
        [_commentWan mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_commentsCountLb.mas_top).mas_equalTo(0);
            make.right.mas_equalTo(-30);
        }];
    }
    return _commentWan;
}
//视频
-(UIButton *)HighURLBtn{
    if (!_HighURLBtn) {
        _HighURLBtn = [[UIButton alloc]init];
        [self.contentView addSubview:_HighURLBtn];
        UIImageView *image = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"waitingVideo"]];
        [_HighURLBtn addSubview:image];
        [image mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_HighURLBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(_commentWan.mas_bottom).mas_equalTo(20);
            make.left.mas_equalTo(10);
            make.bottom.mas_equalTo(-10);
            make.right.mas_equalTo(-5);
            
//            make.height.mas_equalTo(140);
        }];
          }
    return _HighURLBtn;
}



- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

//使用单例：只初始化一次，即在同一个时间只有一个播放器
+(AVPlayerViewController *)sharedInstance{
    static AVPlayerViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        vc = [[AVPlayerViewController alloc]init];
    });
    return vc;
}












/**
 *  如果cell被复用了，需要把cell上的播放器删掉
 */
-(void)prepareForReuse{
    [super prepareForReuse];
    if (![[VideoCell sharedInstance].view isEqual:@"nil"]) {
        [[VideoCell sharedInstance].view removeFromSuperview];
        [VideoCell sharedInstance].player = nil;
    }
}








@end
