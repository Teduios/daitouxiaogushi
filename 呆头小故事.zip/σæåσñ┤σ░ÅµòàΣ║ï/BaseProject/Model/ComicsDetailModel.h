//
//  ComicsDetailModel.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ComicsDetailDataModel,ComicsDetailDataTopicModel,ComicsDetailDataTopicUserModel,ComicsDetailDataBannerInfoModel;

@interface ComicsDetailModel : BaseModel

@property (nonatomic, copy) NSString *message;
@property (nonatomic, strong) ComicsDetailDataModel *data;
@property (nonatomic, assign) NSInteger code;
@end


@interface ComicsDetailDataModel : BaseModel

@property (nonatomic, strong) ComicsDetailDataBannerInfoModel *banner_info;
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *next_comic_id;
@property (nonatomic, assign) BOOL is_favourite;
@property (nonatomic, assign) BOOL is_liked;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, assign) NSInteger previous_comic_id;
@property (nonatomic, assign) NSInteger recommend_count;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) ComicsDetailDataTopicModel *topic;
@property (nonatomic, assign) NSInteger updated_at;
@property (nonatomic, strong) NSArray *images;
@property (nonatomic, assign) NSInteger comments_count;//评论数
@property (nonatomic, assign) NSInteger likes_count;//赞数量

@end

@interface ComicsDetailDataTopicModel : BaseModel
@property (nonatomic, copy) NSString *vertical_image_url;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, assign) NSInteger order;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) NSInteger comics_count;
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *desc;
@property (nonatomic, assign) NSInteger updated_at;
@property (nonatomic, strong) ComicsDetailDataTopicUserModel *user;

@end

@interface ComicsDetailDataTopicUserModel : BaseModel

@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *avatar_url;
@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *reg_type;

@end

@interface ComicsDetailDataBannerInfoModel : BaseModel

@property (nonatomic, assign) NSInteger type;

@end

