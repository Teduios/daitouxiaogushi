//
//  VideoModel.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class VideoItemsModel,VideoItemsVotesModel,VideoItemsUserModel;
@interface VideoModel : BaseModel

@property (nonatomic, assign) NSInteger err;//0
@property (nonatomic, assign) NSInteger refresh;//500
@property (nonatomic, assign) NSInteger count;//10
@property (nonatomic, strong) NSArray *items;
@property (nonatomic, assign) NSInteger total;//500
@property (nonatomic, assign) NSInteger page;//1

@end


@interface VideoItemsModel : BaseModel

@property (nonatomic, copy) NSString *image;
@property (nonatomic, assign) NSInteger published_at;
@property (nonatomic, copy) NSString *image_size;
@property (nonatomic, assign) NSInteger comments_count;//评论数量
@property (nonatomic, copy) NSString *tag;
@property (nonatomic, assign) BOOL allow_comment;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, strong) VideoItemsUserModel *user;//作者信息
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *format;
@property (nonatomic, strong) VideoItemsVotesModel *votes;
@property (nonatomic, strong) NSArray<NSNumber *> *pic_size;
@property (nonatomic, assign) NSInteger share_count;//分享次数
@property (nonatomic, assign) NSInteger loop;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *pic_url;//作者头像
@property (nonatomic, copy) NSString *low_url;//低质量mp4地址，测试不能用
@property (nonatomic, copy) NSString *high_url;//高质量mp4地址
@property (nonatomic, copy) NSString *content;//标题

@end

@interface VideoItemsVotesModel : BaseModel

@property (nonatomic, assign) NSInteger up;
@property (nonatomic, assign) NSInteger down;

@end

//作者信息
@interface VideoItemsUserModel : BaseModel

@property (nonatomic, copy) NSString *login;//名字
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, assign) NSInteger avatar_updated_at;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *role;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *last_device;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, assign) NSInteger last_visited_at;

@end

