//
//  picAndTextModel.h
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class picAndTextItemsModel,picAndTextItemsVotesModel,picAndTextItemsUserModel,picAndTextItemsImage_SizeModel;
@interface picAndTextModel : BaseModel

@property (nonatomic, assign) NSInteger err;
@property (nonatomic, assign) NSInteger refresh;
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, strong) NSArray<picAndTextItemsModel *> *items;
@property (nonatomic, assign) NSInteger total;
@property (nonatomic, assign) NSInteger page;
@end


@interface picAndTextItemsModel : BaseModel

@property (nonatomic, assign) NSInteger published_at;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *content;//内容
@property (nonatomic, copy) NSString *state;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *tag;
@property (nonatomic, copy) NSString *image;//图片后缀
@property (nonatomic, strong) picAndTextItemsImage_SizeModel *image_size;
@property (nonatomic, copy) NSString *format;
@property (nonatomic, assign) BOOL allow_comment;
@property (nonatomic, assign) NSInteger comments_count;
@property (nonatomic, strong) picAndTextItemsUserModel *user;
@property (nonatomic, assign) NSInteger share_count;
@property (nonatomic, strong) picAndTextItemsVotesModel *votes;

@end




@interface picAndTextItemsVotesModel : BaseModel

@property (nonatomic, assign) NSInteger up;
@property (nonatomic, assign) NSInteger down;

@end

@interface picAndTextItemsUserModel : BaseModel

@property (nonatomic, copy) NSString *login;//名字
@property (nonatomic, copy) NSString *icon;
@property (nonatomic, assign) NSInteger avatar_updated_at;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *role;
@property (nonatomic, assign) NSInteger ID;//id
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *last_device;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, assign) NSInteger last_visited_at;

@end

@interface picAndTextItemsImage_SizeModel : BaseModel
@property (nonatomic, strong) NSArray<NSNumber *> *s;
@property (nonatomic, strong) NSArray<NSNumber *> *m;

@end

