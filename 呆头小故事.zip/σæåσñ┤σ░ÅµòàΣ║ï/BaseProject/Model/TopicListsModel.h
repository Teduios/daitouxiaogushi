//
//  TopicListsModel.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class TopicListsDataModel,TopicListsDataTopicsModel,TopicListsDataTopicUserModel;

@interface TopicListsModel : BaseModel

@property (nonatomic, copy) NSString *message;
@property (nonatomic, strong) TopicListsDataModel *data;
@property (nonatomic, assign) NSInteger code;
@end

@interface TopicListsDataModel : BaseModel
@property (nonatomic, strong) NSArray *topics;
@end

@interface TopicListsDataTopicsModel : BaseModel
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *desc;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, assign) BOOL is_favourite;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) NSInteger order;
@property (nonatomic, assign) NSInteger updated_at;
@property (nonatomic, copy) NSString *vertical_image_url;
@property (nonatomic, assign) NSInteger comments_count;
@property (nonatomic, assign) NSInteger comics_count;
@property (nonatomic, assign) NSInteger likes_count;
@property (nonatomic, strong) TopicListsDataTopicUserModel *user;
@end




@interface TopicListsDataTopicUserModel : BaseModel
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *avatar_url;
@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *reg_type;
@end

