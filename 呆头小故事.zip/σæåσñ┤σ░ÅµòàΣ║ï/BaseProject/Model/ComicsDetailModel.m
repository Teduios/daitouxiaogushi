//
//  ComicsDetailModel.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComicsDetailModel.h"

@implementation ComicsDetailModel

@end


@implementation ComicsDetailDataModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation ComicsDetailDataTopicModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id",@"desc":@"description"};
}



@end


@implementation ComicsDetailDataTopicUserModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation ComicsDetailDataBannerInfoModel

@end


