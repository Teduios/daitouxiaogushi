//
//  PicModel.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicModel.h"

@implementation PicModel


+ (NSDictionary *)objectClassInArray{
    return @{@"items" : [PicItemsModel class]};
}
@end



@implementation PicItemsModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end




@implementation PicItemsVotesModel

@end




@implementation PicItemsUserModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end




@implementation PicItemsImageSizeModel

@end


