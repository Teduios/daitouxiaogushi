//
//  DesignatedTopicListModel.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DesignatedTopicListModel.h"

@implementation DesignatedTopicListModel


@end



@implementation DesignatedTopicListDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"comics" : [DesignatedTopicListDataComicsModel class]};
}

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"desc":@"description",@"ID":@"id"};
}
@end


@implementation DesignatedTopicListDataComicsUserModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}

@end


@implementation DesignatedTopicListDataComicsModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}

@end


