//
//  TopicListsModel.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicListsModel.h"

@implementation TopicListsModel

@end




@implementation TopicListsDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"topics" : [TopicListsDataTopicsModel class]};
}

@end







@implementation TopicListsDataTopicsModel




+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id",@"desc":@"description"};
}



@end






@implementation TopicListsDataTopicUserModel

+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


