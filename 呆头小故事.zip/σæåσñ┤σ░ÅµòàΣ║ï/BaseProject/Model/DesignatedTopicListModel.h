//
//  DesignatedTopicListModel.h
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class DesignatedTopicListDataModel,DesignatedTopicListDataComicsUserModel,DesignatedTopicListDataComicsModel;
@interface DesignatedTopicListModel : BaseModel
@property (nonatomic, copy) NSString *message;
@property (nonatomic, strong) DesignatedTopicListDataModel *data;
@property (nonatomic, assign) NSInteger code;

@end



@interface DesignatedTopicListDataModel : BaseModel

@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, copy) NSString *desc;//描述
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, strong) DesignatedTopicListDataComicsUserModel *user;//作者
@property (nonatomic, assign) BOOL is_favourite;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, strong)NSArray *comics;
@property (nonatomic, copy) NSString *title;//名字
@property (nonatomic, assign) NSInteger order;
@property (nonatomic, assign) NSInteger updated_at;
@property (nonatomic, copy) NSString *vertical_image_url;
@property (nonatomic, assign) NSInteger comments_count;//评论数量
@property (nonatomic, assign) NSInteger comics_count;//
@property (nonatomic, assign) NSInteger likes_count;//赞数量
@property (nonatomic, assign) NSInteger sort;
@end




@interface DesignatedTopicListDataComicsUserModel : BaseModel

@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, copy) NSString *avatar_url;
@property (nonatomic, copy) NSString *nickname;
@property (nonatomic, copy) NSString *reg_type;

@end

@interface DesignatedTopicListDataComicsModel : BaseModel

@property (nonatomic, assign) NSInteger topic_id;
@property (nonatomic, assign) NSInteger likes_count;
@property (nonatomic, assign) NSInteger ID;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *cover_image_url;
@property (nonatomic, assign) NSInteger updated_at;
@property (nonatomic, copy) NSString *url;

@end

