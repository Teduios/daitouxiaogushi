//
//  PicModel.h
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class PicItemsModel,PicItemsVotesModel,PicItemsUserModel,PicItemsImageSizeModel;
@interface PicModel : BaseModel

@property (nonatomic, assign) NSInteger err;
@property (nonatomic, assign) NSInteger refresh;
@property (nonatomic, assign) NSInteger count;
@property (nonatomic, strong) NSArray *items;
@property (nonatomic, assign) NSInteger total;
@property (nonatomic, assign) NSInteger page;


@end


@interface PicItemsModel : BaseModel

@property (nonatomic, assign) NSInteger published_at;
@property (nonatomic, assign) NSInteger ID;//内容ID
@property (nonatomic, copy) NSString *content;//内容
@property (nonatomic, copy) NSString *state;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *tag;
@property (nonatomic, copy) NSString *image;//图片内容后缀
@property (nonatomic, strong) PicItemsImageSizeModel *image_size;
@property (nonatomic, copy) NSString *format;
@property (nonatomic, assign) BOOL allow_comment;
@property (nonatomic, assign) NSInteger comments_count;
@property (nonatomic, strong) PicItemsUserModel *user;
@property (nonatomic, assign) NSInteger share_count;
@property (nonatomic, strong) PicItemsVotesModel *votes;

@end



@interface PicItemsVotesModel : BaseModel

@property (nonatomic, assign) NSInteger up;
@property (nonatomic, assign) NSInteger down;

@end

@interface PicItemsUserModel : BaseModel

@property (nonatomic, copy) NSString *login;//名字
@property (nonatomic, copy) NSString *icon;//头像图片后缀
@property (nonatomic, assign) NSInteger avatar_updated_at;
@property (nonatomic, assign) NSInteger created_at;
@property (nonatomic, copy) NSString *role;
@property (nonatomic, assign) NSInteger ID;//用户ID
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *last_device;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, assign) NSInteger last_visited_at;

@end

@interface PicItemsImageSizeModel : BaseModel

@property (nonatomic, strong) NSArray *s;
@property (nonatomic, strong) NSArray *m;

@end

