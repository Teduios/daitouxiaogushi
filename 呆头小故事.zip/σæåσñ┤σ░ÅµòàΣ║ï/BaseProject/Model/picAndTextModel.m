//
//  picAndTextModel.m
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "picAndTextModel.h"

@implementation picAndTextModel


+ (NSDictionary *)objectClassInArray{
    return @{@"items" : [picAndTextItemsModel class]};
}
@end



@implementation picAndTextItemsModel
+(NSDictionary *)replacedKeyFromPropertyName{
   return @{@"ID":@"id"};
}
@end


@implementation picAndTextItemsVotesModel

@end


@implementation picAndTextItemsUserModel
+(NSDictionary *)replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end


@implementation picAndTextItemsImage_SizeModel

@end


