//
//  WelcomeViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#import "UIView+Extension.h"
#import "PicViewController.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import <RESideMenu.h>
#import "LeftViewController.h"
#import "RightViewController.h"
#import "MainViewController.h"
#import "iCarousel.h"
#define IMAGECOUNT 4
@interface WelcomeViewController ()<iCarouselDataSource,iCarouselDelegate>
@property (nonatomic,strong)iCarousel *ic;
@property (nonatomic,strong)NSArray *imageNames;

@end

@implementation WelcomeViewController

- (iCarousel *)ic {
    if(_ic == nil) {
        _ic = [[iCarousel alloc] init];
        //代理
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 9;

//        _ic.autoscroll = 0;//不自动滚动
        _ic.pagingEnabled = NO;//翻页模式
        _ic.scrollSpeed = 0;//滚动速度
        

    }
    return _ic;
}
//存放的是图片数组
- (NSArray *)imageNames {
    if(_imageNames == nil) {
        
        //获取路径
        NSString *path = [[NSBundle mainBundle]pathForResource:@"welcome" ofType:@"bundle"];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        _imageNames = [fileManager subpathsAtPath:path];

    }
    return _imageNames;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.ic];
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
}
    

- (RESideMenu *)sideMenu {
    if(_sideMenu == nil) {
        
        _sideMenu = [[RESideMenu alloc] initWithContentViewController:[MainViewController defaultNavi] leftMenuViewController:[LeftViewController new] rightMenuViewController:[RightViewController new]];
        //推出侧边栏时的背景图片
        _sideMenu.backgroundImage = [UIImage imageNamed:@"MainBackground-1"];
        _sideMenu.menuPrefersStatusBarHidden = YES;//在菜单出现时不显示状态栏
        _sideMenu.bouncesHorizontally = NO;//不允许菜单到了边缘还可以继续缩小
        
    }
    return _sideMenu;
}
//配置导航栏
-(void)configGlobalUIStyle{
    [[UINavigationBar appearance]setTranslucent:YES];//导航栏不透明
    [[UINavigationBar appearance]setHidden:YES];
    [[UINavigationBar appearance]setTintColor:[UIColor greenSeaColor]];
}

#pragma mark - iCarouselDelegate,iCarouselDataSource
-(NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.imageNames.count;
}
-(UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if (!view) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH)];
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.tag = 100;
        [view addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    //imageNames数组中存的是图片名，以为图片是jpg个事，只能用路径来读取。
    NSString *path = [[NSBundle mainBundle]pathForResource:@"welcome" ofType:@"bundle"];
    path = [path stringByAppendingPathComponent:self.imageNames[index]];
    
    UIImageView *imageView = (UIImageView *)[view viewWithTag:100];
    imageView.image = [UIImage imageWithContentsOfFile:path];
    return view;
}
//两个Cell之间的距离
-(CGFloat)carouselItemWidth:(iCarousel *)carousel{
    return kWindowW - 10;
}


//点击方法
-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    NSLog(@"选择了%ld张",(long)index);
    if (index == 2) {
        NSLog(@"点击了第%ld张，进入主界面控制器",(long)index);
        self.view.window.rootViewController = self.sideMenu;
        [self configGlobalUIStyle];//配置全局UI样式
    }
    
}


@end
