//
//  TitleController.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TitleController.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import "TopicListsViewController.h"
@interface TitleController ()
@property (nonatomic,strong)UIImageView *titleImg;
@end

@implementation TitleController

-(UIImageView *)titleImg{
    if (!_titleImg) {
        _titleImg = [[UIImageView alloc]init];
    }
    return _titleImg;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];

    
    
    //题目
    [self.view addSubview:self.titleImg];
    [self.titleImg setImage:[UIImage imageNamed:@"title"]];
    [self.titleImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(20);
        make.centerX.mas_equalTo(0);
        
    }];
  
}















@end
