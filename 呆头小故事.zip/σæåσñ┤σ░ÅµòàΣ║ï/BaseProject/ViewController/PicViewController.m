//
//  PicViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewController.h"
#import "PicViewModel.h"
#import "PicCell.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import "TopicListsViewController.h"
#import "Factory.h"
#import "PictureViewController.h"
@interface PicViewController ()<UITableViewDelegate,UITableViewDataSource,MWPhotoBrowserDelegate>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)PicViewModel *picVM;
@end

@implementation PicViewController
- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[PicCell class] forCellReuseIdentifier:@"PicCell"];
        self.tableView.separatorStyle = UITableViewCellEditingStyleNone;//去掉分割线
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(0);
        }];
        
        _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.picVM refreshDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error];
                }else{
                    [_tableView reloadData];
                    [_tableView.mj_header endRefreshing];
                }
            }];
        }];
        _tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.picVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.debugDescription];
                }else{
                    [_tableView reloadData];
                    [_tableView.mj_footer endRefreshing];
                }
            }];
        }];
    }
    return _tableView;
}

-(PicViewModel *)picVM{
    if (!_picVM) {
        _picVM = [[PicViewModel alloc]init];
    }
    return _picVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addAmusingItemToVC:self];
    [Factory addCartoonItemToVC:self];
    [Factory addTitleItemToVC:self];
    [self.tableView.mj_header beginRefreshing];
    
    
    
}

+(UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        PicViewController *vc = [[PicViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}



#pragma mark - UITableViewDelegate,UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.picVM.rowNumber;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PicCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PicCell"];
    [cell.iconImageView setImageWithURL:[self.picVM iconForRow:indexPath.section]];
    CALayer *layer = cell.iconImageView.layer;
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:14];
    //名字
    cell.loginLb.text = [self.picVM loginForRow:indexPath.section];
    //内容
    cell.contentLb.text = [self.picVM contentForRow:indexPath.section];
    [cell.contentLb setFont:[UIFont fontWithName:@"Copperplate-Light" size:16]];
    
    NSData *data = [[NSData alloc]initWithContentsOfURL:[self.picVM imageForRow:indexPath.section]];
    [cell.imageImageView setBackgroundImage:[UIImage imageWithData:data] forState:UIControlStateNormal];
    [cell.imageImageView bk_addEventHandler:^(id sender) {
        PictureViewController *vc = [[PictureViewController alloc]init];
        vc.image.image = cell.imageImageView.currentBackgroundImage;
        
        [self presentViewController:vc animated:YES completion:nil];
        
               
        
    } forControlEvents:UIControlEventTouchUpInside];
    cell.selectionStyle = UITableViewCellEditingStyleNone;//cell不可点击
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
}
//头步像素
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}

//脚步像素
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}
-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}


#pragma mark - MWPhotoBrowserDelegate
-(NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser{
    return self.picVM.rowNumber;
}
-(id<MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index{
    MWPhoto *photo = [MWPhoto photoWithURL:[self.picVM imageForRow:index]];
    return photo;
}


@end
