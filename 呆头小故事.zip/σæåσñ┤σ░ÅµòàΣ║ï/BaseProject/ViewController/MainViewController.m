//
//  MainViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MainViewController.h"
#import "Factory.h"
@interface MainViewController ()
@property (nonatomic,strong)UIImageView *backgroundImageView;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addAmusingItemToVC:self];
    [Factory addCartoonItemToVC:self];
    [Factory addTitleItemToVC:self];
    
    //背景图
    [self.view addSubview:self.backgroundImageView];
    [self.backgroundImageView setImage:[UIImage imageNamed:@"MainBackground"]];
    [self.backgroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.right.mas_equalTo(0);
    }];
   
}
+(UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        MainViewController *vc = [[MainViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
        
    });
    return navi;
}
- (UIImageView *)backgroundImageView {
	if(_backgroundImageView == nil) {
		_backgroundImageView = [[UIImageView alloc] init];
	}
	return _backgroundImageView;
}

@end
