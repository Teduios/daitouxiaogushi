//
//  AllSubjectViewController.h
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TopicListsModel.h"
#import "TitleController.h"
#import "TopicListsNetManager.h"
@interface AllSubjectViewController : UIViewController
@property (nonatomic,strong)TopicListsModel *topicModel;
+(UINavigationController *)defaultNavi;
@property (nonatomic)CartoonListType type;
@property (nonatomic,strong)NSString *Series;
@end
