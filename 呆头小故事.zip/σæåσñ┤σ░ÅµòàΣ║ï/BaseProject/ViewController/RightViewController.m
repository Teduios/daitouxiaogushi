//
//  RightViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RightViewController.h"
#import "TopicListsViewController.h"
#import "SuperManViewController.h"
#import "LatestUpdateViewController.h"
#import "NewWorksViewController.h"
#import "AllSubjectViewController.h"
@interface RightViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSArray *itemNames;
@end

@implementation RightViewController
-(NSArray *)itemNames{
    //配置右边栏的题目
    return @[@"最热点击量",@"超人气制作",@"巨星出炉",@"阿呆推荐",@"所有专题"];
}
-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        _tableView.tableFooterView = [[UIView alloc]init];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"LeftCell"];
        _tableView.backgroundColor = [UIColor clearColor];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(kWindowW/2, kWindowH/2));
//            make.centerY.mas_equalTo(0);
            make.top.mas_equalTo(150);
            make.left.mas_equalTo(230);
            make.right.mas_equalTo(0);
        }];
        _tableView.separatorStyle = UITableViewRowAnimationNone;//去掉分割线
    }
    return _tableView;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView reloadData];
    
}


#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.itemNames.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.textLabel.text = self.itemNames[indexPath.row];
        cell.backgroundColor = [UIColor clearColor];
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.textLabel.textColor = [UIColor brownColor];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
        return cell;
    }
    
    
    
    return cell;
}
kRemoveCellSeparator
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
            
        case 0:
            
            [self.sideMenuViewController setContentViewController:[TopicListsViewController defaultNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        {
            TopicListsViewController *vc = [[TopicListsViewController alloc]init];
            vc.Series = self.itemNames[0];

        }
            break;
        case 1:
            [self.sideMenuViewController setContentViewController:[SuperManViewController defaultNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        {
            SuperManViewController *vc = [[SuperManViewController alloc]init];
            vc.Series = self.itemNames[1];

        }
            
            break;
        case 2:
            [self.sideMenuViewController setContentViewController:[NewWorksViewController defaultNavi] animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        {
            NewWorksViewController *vc = [[NewWorksViewController alloc]init];
            vc.Series = self.itemNames[2];

        }
         break;
        case 3:
            [self.sideMenuViewController setContentViewController:[LatestUpdateViewController defaultNavi]animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        {
            LatestUpdateViewController *vc = [[LatestUpdateViewController alloc]init];
            vc.Series = self.itemNames[3];
            NSLog(@"%@",self.itemNames[3]);
            [LatestUpdateViewController defaultNavi].title = self.itemNames[3];
            NSLog(@"%@",vc.Series);
        
        }
            break;
        case 4:
            [self.sideMenuViewController setContentViewController:[AllSubjectViewController defaultNavi]animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        {
            AllSubjectViewController *vc = [[AllSubjectViewController alloc]init];
            vc.Series = self.itemNames[4];
        }
        default:
            break;
    }
}



@end
