//
//  picAndTextViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "picAndTextViewController.h"
#import "picAndTextViewModel.h"
#import "picAndTextCell.h"
#import "PicViewController.h"
#import "TopicListsViewController.h"
#import "VideoViewController.h"
#import "Factory.h"
#import "PictureViewController.h"
@interface picAndTextViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)picAndTextViewModel *picAndTextVM;
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSFileManager *manager;
@property (nonatomic,strong)NSString *documentsPath;
@property (nonatomic,strong)NSString  *fontName;


@end

@implementation picAndTextViewController
- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[picAndTextCell class] forCellReuseIdentifier:@"picAndTextCell"];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(0);
        }];
        _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.picAndTextVM getDataFromNetCompleteHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                    [_tableView.mj_footer resetNoMoreData];
                }
                
                [_tableView.mj_header endRefreshing];
            }];
        }];
        _tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.picAndTextVM getMoreDataCompletionHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                    [_tableView.mj_footer endRefreshing];
                }
            }];
        }];
    }
    return _tableView;
}

-(NSFileManager *)manager{
    if (!_manager) {
        //defaultManager 单例模式初始化
        _manager = [NSFileManager defaultManager];
    }
    return _manager;
}
-(NSString *)documentsPath{
    if (!_documentsPath) {
        _documentsPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    }
    return _documentsPath;
}

-(picAndTextViewModel *)picAndTextVM{
    if (!_picAndTextVM) {
        _picAndTextVM = [[picAndTextViewModel alloc]init];
    }
    return _picAndTextVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView.mj_header beginRefreshing];
    self.view.backgroundColor = [UIColor whiteColor];
    [Factory addAmusingItemToVC:self];
    [Factory addCartoonItemToVC:self];
    [Factory addTitleItemToVC:self];
   }


+(UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        picAndTextViewController *vc = [[picAndTextViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}





#pragma mark - UITableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.picAndTextVM.rowNumber;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    picAndTextCell *cell = [tableView dequeueReusableCellWithIdentifier:@"picAndTextCell"];
    //名字
    cell.loginLb.text = [self.picAndTextVM loginForRow:indexPath.section];
    [cell.iconImageView setImageWithURL:[self.picAndTextVM headIconForRow:indexPath.section]placeholderImage:[UIImage imageNamed:@"nodata"]];
    //头像圆形
    CALayer *layer = cell.iconImageView.layer;
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:14];
    
    if ([self.picAndTextVM imageSuffixForRow:indexPath.section].length != 0) {
        NSLog(@"图片后缀：%ld",(unsigned long)[self.picAndTextVM imageSuffixForRow:indexPath.section].length);
        NSData *data = [[NSData alloc]initWithContentsOfURL:[self.picAndTextVM imageForRow:indexPath.section]];
        [cell.imageImageView setBackgroundImage:[UIImage imageWithData:data] forState:UIControlStateNormal];
        [cell.imageImageView bk_addEventHandler:^(id sender) {
            PictureViewController *vc = [[PictureViewController alloc]init];
            vc.image.image = cell.imageImageView.currentBackgroundImage;
            [self presentViewController:vc animated:YES completion:nil];
        } forControlEvents:UIControlEventTouchUpInside];
        
    }else{
        [cell.imageImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(-10);
        }];
    }
    //内容
    cell.contentLb.text = [self.picAndTextVM contentForRow:indexPath.section];
    [cell.contentLb setFont:[UIFont fontWithName:@"HiraginoSans-W3" size:18]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//头步像素
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}

//脚步像素
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}



@end
