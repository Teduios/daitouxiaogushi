//
//  EveryStoryDetailViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "EveryStoryDetailViewController.h"
#import "ComicsDetailViewModel.h"
#import "ComicsDetailCell.h"
#import "Factory.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
@interface EveryStoryDetailViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)ComicsDetailViewModel *ComicsVM;
@property (nonatomic,strong)UINavigationController *navi;
@end

@implementation EveryStoryDetailViewController
-(ComicsDetailViewModel *)ComicsVM{
    if (!_ComicsVM) {
        _ComicsVM = [[ComicsDetailViewModel alloc]init];
        _ComicsVM.ID = _ID;
    }
    return _ComicsVM;
}
- (UINavigationController *)navi {
    if(_navi == nil) {
        EveryStoryDetailViewController *vc = [[EveryStoryDetailViewController alloc]init];
        _navi = [[UINavigationController alloc]initWithRootViewController:vc];
    }
    return _navi;
}


-(UITableView *)tableView{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        self.navigationItem.title = self.title;
        self.tableView.tableFooterView.hidden = YES;
        self.tableView.separatorStyle = UITableViewCellEditingStyleNone;//去掉分割线
        self.tableView.separatorStyle = NO;
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.ComicsVM refreshDataCompletionHandle:^(NSError *error) {
                [self.tableView reloadData];
                [self.tableView.mj_header endRefreshing];
            }];
        }];
        [self.tableView registerClass:[ComicsDetailCell class] forCellReuseIdentifier:@"ComicsDetailCell"];
        
        
    }
    return _tableView;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
    self.tableView.tableFooterView.hidden = YES;
    self.tableView.separatorStyle = UITableViewCellEditingStyleNone;//去掉分割线
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.ComicsVM refreshDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.mj_header endRefreshing];
        }];
    }];
    [self.tableView.mj_header beginRefreshing];
    UISwipeGestureRecognizer *swipGR = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swip:)];
    swipGR.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:swipGR];
    
}


-(void)swip:(UISwipeGestureRecognizer *)gr{
    if (gr.direction == UISwipeGestureRecognizerDirectionRight) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}




#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.ComicsVM.rowNumber;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ComicsDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ComicsDetailCell"];
 
    [cell.image setImageWithURL:[NSURL URLWithString:[self.ComicsVM imagesForRow:indexPath.row][indexPath.row]]];
    cell.selectionStyle = UITableViewCellEditingStyleNone;//cell不可点击
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return (kWindowW/1.28)+2;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}






@end
