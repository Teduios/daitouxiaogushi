//
//  DesignatedTopicListViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DesignatedTopicListViewController.h"
#import "DesignatedTopicListViewModel.h"
#import "ComicsCell.h"
#import "EveryStoryDetailViewController.h"
#import "Factory.h"
#import "picAndTextViewController.h"
#import "PicViewController.h"
#import "VideoViewController.h"
@interface DesignatedTopicListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)DesignatedTopicListViewModel *DesignatedVM;
@property (nonatomic,strong)UINavigationController *navi;
@end

@implementation DesignatedTopicListViewController
- (UINavigationController *)navi {
    if(_navi == nil) {
        DesignatedTopicListViewController *vc = [[DesignatedTopicListViewController alloc]init];
        _navi = [[UINavigationController alloc]initWithRootViewController:vc];
    }
    return _navi;
}
- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[ComicsCell class] forCellReuseIdentifier:@"ComicsCell"];
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.DesignatedVM refreshDataCompletionHandle:^(NSError *error) {
                [self.tableView reloadData];
                [self.tableView.mj_header endRefreshing];
            }];
        }];
        
        self.tableView.tableFooterView = [[UIView alloc]init];
    }
    return _tableView;
}



-(DesignatedTopicListViewModel *)DesignatedVM{
    if (!_DesignatedVM) {
        _DesignatedVM = [[DesignatedTopicListViewModel alloc]init];
        _DesignatedVM.ID = _ID;
        NSLog(@"self.ID:%ld",(long)_ID);
    }
    return _DesignatedVM;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addBackItemToVC:self];
    [Factory addTitleItemToVC:self];
    [self.tableView.mj_header beginRefreshing];
    
}


#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.DesignatedVM.rowNumber;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ComicsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ComicsCell"];
    [cell.likeImage setImage:[UIImage imageNamed:@"赞图标"]];
    cell.wan.text = @"万";
    [cell.coverImageView setImageWithURL:[self.DesignatedVM coverImageURLForRow:indexPath.row]];
    cell.titleLb.text = [self.DesignatedVM titleForRow:indexPath.row];
    cell.likesCountLb.text = [NSString stringWithFormat:@"%ld",(unsigned long)[self.DesignatedVM likesCountForRow:indexPath.row]];
    
    
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    EveryStoryDetailViewController *vc = [[EveryStoryDetailViewController alloc]init];
    [self presentViewController:vc animated:YES completion:nil];
    vc.ID = [self.DesignatedVM IDForRow:indexPath.row];
    vc.text = [self.DesignatedVM titleForRow:indexPath.row];

    
    
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}



@end
