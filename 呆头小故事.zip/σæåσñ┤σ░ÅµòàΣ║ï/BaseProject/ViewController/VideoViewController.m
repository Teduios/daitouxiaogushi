//
//  VideoViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoViewController.h"
#import "VideoViewModel.h"
#import "VideoCell.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import "TopicListsViewController.h"
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import "Factory.h"
@interface VideoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;

@property (nonatomic,strong)VideoViewModel *VideoVM;
@end

@implementation VideoViewController
-(VideoViewModel *)VideoVM{
    if (!_VideoVM) {
        _VideoVM = [[VideoViewModel alloc]init];
    }
    return _VideoVM;
}

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[VideoCell class] forCellReuseIdentifier:@"VideoCell"];
    }
    //刷新
    _tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.VideoVM refreshDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error];
            }else{
                [_tableView reloadData];
                //重置脚步视图，没有更多数据
                [_tableView.mj_footer resetNoMoreData];
            }
            
            [_tableView.mj_header endRefreshing];
        }];
    }];
    _tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self.VideoVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.localizedDescription];
            }else{
                [_tableView reloadData];
            }
            
            [_tableView.mj_footer endRefreshing];
        }];
    }];
    
    
    
    return _tableView;
}

+(UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        VideoViewController *vc = [[VideoViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"黑体");
    NSLog(@"******************************************");
    for(NSString *fontfamilyname in [UIFont familyNames])
    {
        NSLog(@"\tfamily:'%@'",fontfamilyname);
        for(NSString *fontName in [UIFont fontNamesForFamilyName:fontfamilyname])
        {
            NSLog(@"\tfont:'%@'",fontName);
        }
    }
     NSLog(@"******************************************");
       [self.tableView.mj_header beginRefreshing];
    
    [Factory addAmusingItemToVC:self];
    [Factory addCartoonItemToVC:self];
    [Factory addTitleItemToVC:self];
}


#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.VideoVM.rowNumber;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    VideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"VideoCell"];
    cell.contentLb.text = [self.VideoVM contentForRow:indexPath.section];
    cell.loginLb.text = [self.VideoVM logLinForRow:indexPath.section];
    [cell.picURLImageView setImageWithURL:[self.VideoVM picURLForRow:indexPath.section]];
    CALayer *layer = cell.picURLImageView.layer;
     [layer setMasksToBounds:YES];
    layer.cornerRadius = 14;
    
    
    cell.commentsCountLb.text = [NSString stringWithFormat:@"%ld",(unsigned long)[self.VideoVM commentsCountForRow:indexPath.section]];
    cell.shareCountLb.text = [NSString stringWithFormat:@"%ld",(unsigned long)[self.VideoVM shareCountForRow:indexPath.section]];
    cell.videoURL = [self.VideoVM highURLForRow:indexPath.section];
    [cell.likeIcon setImage:[UIImage imageNamed:@"赞图标"]];
    cell.likeWan.text = @"万";
    [cell.commentIcon setImage:[UIImage imageNamed:@"评论图标"]];
    cell.commentWan.text = @"万";
    
    [cell.HighURLBtn bk_addEventHandler:^(id sender) {
        //把视频放在单独的线程里
        AVPlayer *player = [AVPlayer playerWithURL:cell.videoURL];
        [player play];
        [VideoCell sharedInstance].player = player;
        [sender addSubview:[VideoCell sharedInstance].view];
        [[VideoCell sharedInstance].view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        
    } forControlEvents:UIControlEventTouchUpInside];

        return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"%ld",(long)indexPath.section);
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
}
//头步像素
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}

//脚步像素
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}


//行高
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat height = kWindowW *540.0/720;
    return height;
}
@end
