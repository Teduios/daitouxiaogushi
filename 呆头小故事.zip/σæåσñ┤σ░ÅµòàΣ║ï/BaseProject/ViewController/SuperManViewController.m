//
//  SuperManViewController.m
//  BaseProject
//
//  Created by tarena on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SuperManViewController.h"
#import "TopicListsViewModel.h"
#import "TopicListsCell.h"
#import "DesignatedTopicListViewController.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import "Factory.h"

@interface SuperManViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)TopicListsViewModel *topicVM;
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,  strong)NSIndexPath *row;
@property (nonatomic)NSInteger row1;
@property (nonatomic,strong)NSString *name;
@property (nonatomic,strong)UINavigationController *navi;
@end


@implementation SuperManViewController

- (UINavigationController *)navi {
    if(_navi == nil) {
        SuperManViewController *vc = [[SuperManViewController alloc]init];
        _navi = [[UINavigationController alloc]initWithRootViewController:vc];
    }
    return _navi;
}

- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.bottom.right.mas_equalTo(0);
        }];
        [_tableView registerClass:[TopicListsCell class] forCellReuseIdentifier:@"TopicListCell"];
        self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.topicVM refreshDataCompletionHandle:^(NSError *error) {
                
                [self.tableView reloadData];
                [self.tableView.mj_header endRefreshing];
            }];
        }];
        self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.topicVM getMoreDataCompletionHandle:^(NSError *error) {
                self.tableView.estimatedRowHeight = UITableViewAutomaticDimension;
                [self.tableView reloadData];
                [self.tableView.mj_footer endRefreshing];
            }];
        }];
        [self.tableView.mj_header beginRefreshing];
        
    }
    return _tableView;
}


-(NSIndexPath *)row
{
    if (!_row) {
        _row=[NSIndexPath new];
    }
    return _row;
}
- (TopicListsViewModel *)topicVM {
    if(_topicVM == nil) {
        _topicVM = [[TopicListsViewModel alloc] initWithNewsListType:CartoonListTypeSuperMan];
    }
    return _topicVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [Factory addCartoonItemToVC:self];
    [Factory addAmusingItemToVC:self];
    [Factory addTitleItemToVC:self];
    self.row = 0;
    [self.tableView.mj_header beginRefreshing];
    self.title = self.Series;
}



+(UINavigationController *)defaultNavi{
    static UINavigationController *navi = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        SuperManViewController *vc = [[SuperManViewController alloc]init];
        navi = [[UINavigationController alloc]initWithRootViewController:vc];
    });
    return navi;
}






#pragma mark - UITableViewDataSource,UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.topicVM.rowNumber;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TopicListsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TopicListCell"];
    [cell.coverImageView setImageWithURL:[self.topicVM coverImageForRow:indexPath.row]];
    cell.titleLb.text = [self.topicVM titleForRow:indexPath.row];
    cell.titleLb.text = [cell.titleLb.text stringByReplacingOccurrencesOfString:@"  " withString:@""];
    cell.titleLb.text = [cell.titleLb.text stringByReplacingOccurrencesOfString:@" " withString:@""];
    cell.nickNameLb.text = [self.topicVM nickNameForRow:indexPath.row];
    cell.likesCountLb.text = [NSString stringWithFormat:@"%ld",(unsigned long)[self.topicVM likesCountForRow:indexPath.row]];
    cell.commentsCountLb.text = [NSString stringWithFormat:@"%ld",(unsigned long)[self.topicVM commentsCountForRow:indexPath.row]];
    cell.descLb.text = [self.topicVM descForRow:indexPath.row];
    cell.likeWan.text = @"万";
    cell.commentWan.text = @"万";
    [cell.zan setImage:[UIImage imageNamed:@"赞图标"]];
    [cell.commentIcon setImage:[UIImage imageNamed:@"评论图标"]];
    return cell;
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.row=indexPath;
    [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    DesignatedTopicListViewController *vc = [[DesignatedTopicListViewController alloc]init];
    vc.ID=[self.topicVM IDForRow:indexPath.row];
    vc.Title=[self.topicVM titleForRow:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
    [self.view removeFromSuperview];
    
    
}

-(CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}
@end
