//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "PicViewController.h"
#import "picAndTextViewController.h"
#import "VideoViewController.h"
#import <RESideMenu.h>
#import "LeftViewController.h"
#import "RightViewController.h"
#import "MainViewController.h"
#import "WelcomeViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
    self.window.rootViewController = [[WelcomeViewController alloc]init];
    [self.window makeKeyAndVisible];
    [self initializeWithApplication:application];
    return YES;
}
- (UIWindow *)window{
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}




@end
