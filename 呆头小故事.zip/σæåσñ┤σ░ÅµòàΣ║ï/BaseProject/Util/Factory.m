//
//  Factory.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "Factory.h"

@implementation Factory
//搞笑
+ (void)addAmusingItemToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"搞笑"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"搞笑"] forState:UIControlStateHighlighted];
    btn.frame = CGRectMake(0, 0, 40, 40);
    [btn bk_addEventHandler:^(id sender) {
        [vc.sideMenuViewController presentLeftMenuViewController];
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *menuItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = 5;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,menuItem];
}

/** 向某个控制器上，添加返回按钮 */
+ (void)addBackItemToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateHighlighted];
    btn.frame = CGRectMake(0, 0, 40, 40);
    [btn bk_addEventHandler:^(id sender) {
        [vc.navigationController popViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *menuItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = 5;
    vc.navigationItem.leftBarButtonItems = @[spaceItem,menuItem];
}
//卡通按钮
+ (void)addCartoonItemToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"漫画"] forState:UIControlStateNormal];//正常状态
    [btn setBackgroundImage:[UIImage imageNamed:@"漫画"] forState:UIControlStateHighlighted];//点击状态
    btn.frame = CGRectMake(270, 0, 40, 40);
    [btn bk_addEventHandler:^(id sender) {
        [vc.sideMenuViewController presentRightMenuViewController];
    } forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *menuItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    //使用弹簧控件缩小菜单按钮和边缘距离
    UIBarButtonItem *spaceItem=[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceItem.width = 5;
    vc.navigationItem.rightBarButtonItems = @[spaceItem,menuItem];
    
}

//添加题目
+ (void)addTitleItemToVC:(UIViewController *)vc{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:@"title"] forState:UIControlStateNormal];//正常状态
    [btn setBackgroundImage:[UIImage imageNamed:@"title"] forState:UIControlStateHighlighted];//点击状态
    btn.frame = CGRectMake(270, 0, 40, 40);
    vc.navigationItem.titleView = btn;
//    vc.navigationItem.titleView.frame = CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)
    
}
@end












