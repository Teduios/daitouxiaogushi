//
//  Factory.h
//  BaseProject
//
//  Created by jiyingxin on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Factory : NSObject
//返回卡通菜单
+ (void)addCartoonItemToVC:(UIViewController *)vc;

//返回按钮
+ (void)addBackItemToVC:(UIViewController *)vc;

//返回搞笑菜单
+ (void)addAmusingItemToVC:(UIViewController *)vc;

//题目
+ (void)addTitleItemToVC:(UIViewController *)vc;

@end









