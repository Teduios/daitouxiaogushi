//
//  ScrollDisplayViewController.m
//  BaseProject
//
//  Created by tarena on 15/10/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ScrollDisplayViewController.h"

@interface ScrollDisplayViewController ()<UIPageViewControllerDelegate,UIPageViewControllerDataSource>

@end

@implementation ScrollDisplayViewController
#pragma mark - viewDidLoad
- (void)viewDidLoad {
    [super viewDidLoad];
    //如果控制器数组为空或者什么都没有
    if (!self.controllers || self.controllers.count == 0) {
        return;
    }
//    self.pageVC = [[UIPageViewController alloc]initWithTransitionStyle:1 navigationOrientation:0 options:nil];
    _pageVC = [[UIPageViewController alloc]initWithTransitionStyle:1 navigationOrientation:0 options:nil];
    self.pageVC.delegate = self;
    self.pageVC.dataSource = self;
    [self addChildViewController:self.pageVC];
    [self.view addSubview:self.pageVC.view];
    //需要使用pod引入Masonry第三方类库
    [self.pageVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    [self.pageVC setViewControllers:@[self.controllers.firstObject] direction:0 animated:YES completion:nil];
    
    //小圆点的设置
//    self.pageControl = [[UIPageControl alloc]init];
    _pageControl = [[UIPageControl alloc]init];
    self.pageControl.numberOfPages = self.controllers.count;
    [self.view addSubview:self.pageControl];
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view);
        make.bottom.mas_equalTo(0);
    }];
    self.pageControl.userInteractionEnabled = NO;//去掉用户交互事件
    
//配置小圆点个性化属性的初始化操作
    self.autoCycle = _autoCycle;
    self.showPageControl = _showPageControl;
    self.pageControlOffset = _pageControlOffset;
}
#pragma mark - 在实现传入图片地址方法之前需要判断传入的图片的路径类型：网络or本地
//判断传入的图片的路径类型
-(BOOL)isURL:(id)path{
    return [path isKindOfClass:[NSURL class]];
}

//判断是否是网络类型
-(BOOL)isNetPath:(id)path{
    BOOL isStr = [path isKindOfClass:[NSString class]];
    //为了防止非String类型调用下方崩溃
    if (!isStr) {
        return NO;
    }
    BOOL containHttp = [path rangeOfString:@"http"].location != NSNotFound;
    //tile:片状材料
    BOOL containTile = [path rangeOfString:@"://"].location != NSNotFound;
    return isStr && containHttp &&containTile;
    
    
    //另一种写法：
    ////    http://  https://
    //    return [path isKindOfClass:[NSString class]] && [path rangeOfString:@"http"].location != NSNotFound && [path rangeOfString:@"https"].location != NSNotFound;
}

#pragma mark - 实现传入图片地址、图片名字、视图控制器的方法
//传入图片地址数组
-(instancetype)initWithImgPaths:(NSArray *)paths{
//路径中可能的类型：NSURL,Http://,Https://,本地路径：file://
    NSMutableArray *arr = [[NSMutableArray alloc]init];
    for (int i = 0; i<paths.count; i++) {
        id path = paths[i];
//        UIImageView *imageView = [[UIImageView alloc]init];
//为了监控用户点击操作
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        if ([self isURL:path]) {
            //URL类型
//            [imageView sd_setImageWithURL:path];
            //0:UIControlStateNormal
            [btn sd_setBackgroundImageWithURL:path forState:0];
            
        }else if([self isNetPath:path]){
            //网络类型
//            NSURL *url = [NSURL URLWithString:path];
//            [imageView sd_setImageWithURL:url];
            [btn sd_setBackgroundImageWithURL:path forState:0];
        }else if([path isKindOfClass:[NSString class]]){
            //本地地址
//            NSURL *url = [NSURL fileURLWithPath:path];
//            [imageView sd_setImageWithURL:url];
            [btn sd_setBackgroundImageWithURL:path forState:0];
        }else{
            //传入的路径什么类型都不是的时候显示一个裂开的图片
            //这里可以给imageView设置成一个裂开的本地图片
//            imageView.image = [UIImage imageNamed:@"error@3x"];
            [btn setImage:[UIImage imageNamed:@"error@3x"] forState:0];
        }
        UIViewController *vc = [[UIViewController alloc]init];
//        vc.view = imageView;//imageView->UIViewController
        vc.view = btn;
        btn.tag = 1000+i;//默认tag是0，为防止与i = 0重复，加个数
        NSLog(@"btn.tag:%ld",(long)btn.tag);
        [btn bk_addEventHandler:^(UIButton *sender) {
            [self.delegate scrollDisplayViewController:self didSelectedRowIndex:sender.tag - 1000];
        } forControlEvents:UIControlEventTouchUpInside];
        [arr addObject:vc];
    }
    self = [self initWithControllers:arr];
    return self;
}
//+ 调用方法用类名： [ScrollDisplayViewController isURL:path];
//- 调用方法用self： [self isURL:path];




//传入图片名字数组
-(instancetype)initWithImgNames:(NSArray *)names{
//        把图片名字转化成成图片视图再转化为ViewController，最后赋值给_ViewControllers
        //图片名字->Image->imageView->ViewController
        NSMutableArray*arr = [[NSMutableArray alloc]init];
        for (int i = 0; i<names.count; i++) {
            UIImage *image = [UIImage imageNamed:names[i]];
//            UIImageView *iv = [[UIImageView alloc]initWithImage:image];
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setBackgroundImage:image forState:0];
            UIViewController *vc = [[UIViewController alloc]init];
//            vc.view = iv;//将imageView转化为ViewController
            vc.view = btn;
            btn.tag = 1000+ i;
            [btn bk_addEventHandler:^(UIButton *sender) {
                [self.delegate scrollDisplayViewController:self  didSelectedRowIndex:sender.tag - 1000];
            } forControlEvents:UIControlEventTouchUpInside];
//            [vc.view addSubview:iv];
            
            [arr addObject:vc];
        }
    if (self = [self initWithControllers:arr]) {
    }
    
    return self;
}
//传入视图控制器
-(instancetype)initWithControllers:(NSArray *)controllers{
    if (self = [super init]) {
        //为了防止实参（传入的参数）是可变数组，需要复制一份出来这样可以保证属性不会因为可变数组在外部被修改而导致随之也修改了
//        self.controllers = [controllers copy];
        _controllers = [controllers copy];
        self.autoCycle = YES;
        self.canCycle = YES;
        self.showPageControl = YES;
        self.duration = 3;
        self.pageControlOffset = 0;
    }
    return self;
}

#pragma mark - 配置小圆点位置
-(void)configPageControl{
    NSInteger index = [self.controllers indexOfObject:self.pageVC.viewControllers.firstObject];//获取当前视图的索引值
    self.pageControl.currentPage = index;
}


#pragma mark - 重写配置小圆点个性化属性的set方法
-(void)setAutoCycle:(BOOL)autoCycle{
    _autoCycle = autoCycle;
    //invalidate:使无效
//    [self.timer invalidate];
    [_timer invalidate];
    if (!autoCycle) {//如果为NO
        return ;
    }
    _timer = [NSTimer bk_scheduledTimerWithTimeInterval:self.duration block:^(NSTimer *timer) {
        UIViewController *vc = self.pageVC.viewControllers.firstObject;
        NSInteger index = [self.controllers indexOfObject:vc];
        UIViewController *nextVC = nil;
        if (index == self.controllers.count - 1) {
            if (!_canCycle) {
                return;
            }
            nextVC = self.controllers.firstObject;
        }else{
            nextVC = self.controllers[index + 1];
        }
        __block ScrollDisplayViewController *vc1 = self;
        [_pageVC setViewControllers:@[nextVC] direction:0 animated:YES completion:^(BOOL finished) {
            [vc1 configPageControl];
        }];
    } repeats:YES];
}

-(void)setShowPageControl:(BOOL)showPageControl{
    _showPageControl = showPageControl;
    _pageControl.hidden = !showPageControl;
}

-(void)setDuration:(NSTimeInterval)duration{
    _duration = duration;
    _autoCycle = self.autoCycle;//重新启用
    
}

-(void)setPageControlOffset:(CGFloat)pageControlOffset{
    _pageControlOffset = pageControlOffset;
    //更新页面数量控件 bottom约束
    [self.pageControl mas_updateConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(pageControlOffset);//_pageControlOffset
    }];
}


#pragma mark - UIPageViewControllerDataSource协议
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    NSInteger index = [self.controllers indexOfObject:viewController];
    
    if (index == 0) {
        return self.canCycle?self.controllers.lastObject : nil;
    }
    return self.controllers[index - 1];
    
}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    NSInteger index = [self.controllers indexOfObject:viewController];
    
    if (index == self.controllers.count - 1) {
        return self.canCycle?self.controllers.firstObject : nil;
    }
    return self.controllers[index + 1];
    
}

#pragma mark - UIPageViewControllerDelegate协议
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed{
    if (completed && finished) {
        
        [self configPageControl];
        NSInteger index = [self.controllers indexOfObject:pageViewController.viewControllers.firstObject];
        if ([self.delegate respondsToSelector:@selector(scrollDisplayViewController:currentIndex:)]) {
            [self.delegate scrollDisplayViewController:self currentIndex:index];
        }

    }
}


//设置当前页的方法
-(void)setCurrentPage:(NSInteger)currentPage{
    //设置新的显示页面，情况有三种：
    //情况1：新页面和老页面是同一个，什么都不做
    //情况2：新页面和老页面的右侧，动画效果应该是向右滚动
    //情况3：新页面在老页面的左侧，动画效果应该是向左滚动
    /**
     *      
     UIPageViewControllerNavigationDirectionForward:向右
     UIPageViewControllerNavigationDirectionReverse:向左
     */
    NSInteger direction = 0;
    //滚动方向判断
    if (_currentPage == currentPage) {
        return;
    }else if (_currentPage > currentPage){
        direction = 1;
    }else{
        direction = 0;
    }
    
    _currentPage = currentPage;
    UIViewController *vc = _controllers[currentPage];
    [self.pageVC setViewControllers:@[vc] direction:direction animated:YES completion:nil];
}
@end





















