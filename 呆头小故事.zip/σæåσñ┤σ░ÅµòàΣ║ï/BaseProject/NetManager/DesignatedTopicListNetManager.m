//
//  DesignatedTopicListNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "DesignatedTopicListNetManager.h"
#import "DesignatedTopicListModel.h"
@implementation DesignatedTopicListNetManager

+(id)getTopListsFromID:(NSUInteger)ID  completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *p = @"?sort=1";
    NSString *path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topics/%ld%@",(unsigned long)ID,p];
    NSMutableDictionary *params = [[NSMutableDictionary alloc]init];
    [params setObject:@"0" forKey:@"sort"];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([DesignatedTopicListModel mj_objectWithKeyValues:responseObj],error);
        NSLog(@"path:%@",path);
    }];

}
@end
