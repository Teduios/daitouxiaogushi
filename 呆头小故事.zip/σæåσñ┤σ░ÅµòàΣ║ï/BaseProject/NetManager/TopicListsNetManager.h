//
//  TopicListsNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

typedef NS_ENUM(NSUInteger, CartoonListType) {
    CartoonListTypeMostHot,
    CartoonListTypeSuperMan,
    CartoonListTypeNewWorks,
    CartoonListTypeLatestUpdate,
    CartoonListTypeRecommend,
    CartoonListTypeAllSubject,
};



@interface TopicListsNetManager : BaseNetManager
+(id)getTopListsFromoffset:(NSUInteger)offset kCompletionHandle;

+(id)getCartoonList:(CartoonListType)type page:(NSUInteger)page kCompletionHandle;



@end
