//
//  DesignatedTopicListNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface DesignatedTopicListNetManager : BaseNetManager
+(id)getTopListsFromID:(NSUInteger)ID  kCompletionHandle;
@end
