//
//  VideoNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoNetManager.h"
#import "VideoModel.h"
//http://m2.qiushibaike.com/article/list/video?count=10&page=1
@implementation VideoNetManager
+(id)getVideoInfoFromPage:(NSUInteger)page completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/video?count=10&page=%ld",(unsigned long)page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([VideoModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
