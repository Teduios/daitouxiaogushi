//
//  PicNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicNetManager.h"
#import "PicModel.h"


//http://m2.qiushibaike.com/article/list/imgrank?count=30&page=1
@implementation PicNetManager
+(id)getPicInfoFromPage:(NSUInteger)page kCompletionHandle{
    NSString *path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/imgrank?count=10&page=%ld",(unsigned long)page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([PicModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
