//
//  TopicListsNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "TopicListsNetManager.h"
#import "TopicListsModel.h"

//http://api.kuaikanmanhua.com/v1/topic_lists/1?limit=10&offset=1

@implementation TopicListsNetManager
+(id)getTopListsFromoffset:(NSUInteger)offset completionHandle:(void (^)(id, NSError *))completionHandle{
    NSString *path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/others?limit=10&offset=%ld",(unsigned long)offset];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TopicListsModel mj_objectWithKeyValues:responseObj],error);
    }];
}


+(id)getCartoonList:(CartoonListType)type page:(NSUInteger)page kCompletionHandle{
    NSString *path = nil;
    switch (type) {
        case CartoonListTypeMostHot: {
            path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/1?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        case CartoonListTypeSuperMan: {
        path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/4?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        case CartoonListTypeNewWorks: {
         path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/5?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        case CartoonListTypeLatestUpdate: {
         path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/2?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        case CartoonListTypeRecommend: {
        path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/3?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        case CartoonListTypeAllSubject: {
         path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/topic_lists/others?limit=10&offset=%ld",(unsigned long)page];
            break;
        }
        default: {
            break;
        }

    }
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([TopicListsModel mj_objectWithKeyValues:responseObj],error);
    }];
}

@end
