//
//  picAndTextNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "picAndTextNetManager.h"
#import "picAndTextModel.h"
//http://m2.qiushibaike.com/article/list/suggest?count=10&page=1
@implementation picAndTextNetManager
+(id)getPicAndTextInfoFromPage:(NSUInteger)page kCompletionHandle{
    
    NSString *path = [NSString stringWithFormat:@"http://m2.qiushibaike.com/article/list/suggest?count=10&page=%ld",(unsigned long)page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([picAndTextModel mj_objectWithKeyValues:responseObj],error);
    }];
}
@end
