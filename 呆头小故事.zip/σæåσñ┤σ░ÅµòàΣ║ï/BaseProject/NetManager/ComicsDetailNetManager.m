//
//  ComicsDetailNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ComicsDetailNetManager.h"
#import "ComicsDetailModel.h"

@implementation ComicsDetailNetManager
+(id)getComicsDetailFromID:(NSUInteger)ID completionHandle:(void (^)(id, NSError *))completionHandle{

    NSString *path = [NSString stringWithFormat:@"http://api.kuaikanmanhua.com/v1/comics/%ld",(unsigned long)ID];
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([ComicsDetailModel mj_objectWithKeyValues:responseObj],error);
        NSLog(@"path:%@",path);
    }];
    

}
@end
