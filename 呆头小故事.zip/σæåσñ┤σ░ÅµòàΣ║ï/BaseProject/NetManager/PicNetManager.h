//
//  PicNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface PicNetManager : BaseNetManager
+(id)getPicInfoFromPage:(NSUInteger)page kCompletionHandle;
@end
