//
//  VideoNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
//http://m2.qiushibaike.com/article/list/video?count=10&page=1

@interface VideoNetManager : BaseNetManager
+(id)getVideoInfoFromPage:(NSUInteger)page kCompletionHandle;
@end
