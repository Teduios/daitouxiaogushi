//
//  SuperManComicsDetailNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"

@interface ComicsDetailNetManager : BaseNetManager
+(id)getComicsDetailFromID:(NSUInteger)ID kCompletionHandle;
@end
